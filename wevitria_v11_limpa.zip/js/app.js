
(() => {
  const header = document.getElementById('main-header');
  const menuButton = document.getElementById('menu-toggle');
  const nav = document.getElementById('main-nav');

  const updateHeader = () => header?.classList.toggle('scrolled', window.scrollY > 18);
  updateHeader();
  window.addEventListener('scroll', updateHeader, { passive: true });

  menuButton?.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(open));
  });

  nav?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    nav.classList.remove('open');
    menuButton?.setAttribute('aria-expanded', 'false');
  }));

  const reveal = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    reveal.forEach(el => observer.observe(el));
  } else reveal.forEach(el => el.classList.add('visible'));

  const form = document.getElementById('lead-form');
  form?.addEventListener('submit', event => {
    event.preventDefault();
    const nome = document.getElementById('nome').value.trim();
    const whatsapp = document.getElementById('whatsapp').value.trim();
    const email = document.getElementById('email').value.trim();
    const desafio = document.getElementById('desafio').value.trim();
    const text = `Olá! Gostaria de falar com a Wevitria.\n\nNome: ${nome}\nWhatsApp: ${whatsapp}\nE-mail: ${email}\n\nQual o meu desafio:\n${desafio}`;
    const url = `https://api.whatsapp.com/send?phone=5521981051445&text=${encodeURIComponent(text)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  });
})();
