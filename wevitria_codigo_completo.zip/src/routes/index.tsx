import { createFileRoute } from "@tanstack/react-router";
import {
  ArrowRight,
  BarChart3,
  Brain,
  Calculator,
  CalendarRange,
  Cloud,
  Cpu,
  Gauge,
  Lightbulb,
  Link2,
  Mail,
  MapPin,
  Phone,
  Settings2,
  ShieldCheck,
  Target,
  Timer,
  TrendingUp,
  Users,
} from "lucide-react";

import { ContactForm } from "@/components/ContactForm";

import banner from "@/assets/hero-w.png.asset.json";
import quemSomos from "@/assets/quem-somos.png.asset.json";
import logo from "@/assets/logo-wevitria.jpeg.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Wevitria | Engenharia Digital e Automação de Processos" },
      {
        name: "description",
        content:
          "Soluções digitais sob medida em engenharia: automação de processos, controle de custos, dashboards e IA aplicada ao seu negócio.",
      },
      { property: "og:title", content: "Wevitria | Engenharia Digital" },
      {
        property: "og:description",
        content:
          "Transformamos, digitalizamos e automatizamos processos com engenharia, IA e tecnologia aplicada.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const nav = [
  { label: "Quem somos", href: "#quem-somos" },
  { label: "Diferenciais", href: "#diferenciais" },
  { label: "Soluções", href: "#solucoes" },
  { label: "Contato", href: "#contato" },
];

const metrics = [
  { icon: ShieldCheck, title: "Redução de custos", value: "até 30%" },
  { icon: TrendingUp, title: "Ganho de produtividade", value: "até 40%" },
  { icon: Timer, title: "Tempo de resposta mais ágil", value: "até 60%" },
  { icon: Target, title: "Precisão nas decisões", value: "+ assertividade" },
  { icon: Link2, title: "Sistemas integrados", value: "+ eficiência" },
];

const diferenciais = [
  {
    icon: Users,
    title: "Humanização e automatização de processos",
    text: "Tecnologia a serviço de pessoas e objetivos reais.",
  },
  {
    icon: Brain,
    title: "Inteligência Artificial aplicada ao negócio",
    text: "Decisões mais rápidas, precisas e inteligentes.",
  },
  {
    icon: Lightbulb,
    title: "Soluções criativas por quem conhece obras",
    text: "Experiência real de campo que gera soluções de impacto.",
  },
  {
    icon: Gauge,
    title: "Economia de tempo e redução de custos",
    text: "Mais eficiência, menos desperdícios, melhores resultados.",
  },
];

const solucoes = [
  { icon: Calculator, title: "Engenharia de Custos Digital", text: "Orçamentos precisos e análises inteligentes." },
  { icon: CalendarRange, title: "Planejamento e Project Controls", text: "Cronogramas confiáveis e gestão integrada." },
  { icon: Cpu, title: "Automatização de Processos", text: "RPA e integrações que eliminam retrabalho." },
  { icon: BarChart3, title: "Dashboards e Inteligência de Dados", text: "Informações claras para decisões rápidas." },
  { icon: Cloud, title: "Integração de Sistemas", text: "Conexão entre dados, processos e pessoas." },
  { icon: Settings2, title: "Inovação e Engenharia Digital", text: "Tecnologias modernas aplicadas à engenharia." },
];

function Index() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <header className="sticky top-0 z-50 border-b border-border/60 bg-background/85 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-6 px-5 py-3.5">
          <a href="#topo" className="flex items-center gap-3">
            <img src={logo.url} alt="Logomarca Wevitria" className="h-10 w-10 object-contain" />
            <span className="leading-tight">
              <span className="block text-xl font-extrabold tracking-tight text-brand-deep">wevitria</span>
              <span className="block text-[0.62rem] font-medium tracking-[0.18em] text-muted-foreground">
                DIGITAL ENGINEERING
              </span>
            </span>
          </a>
          <nav className="hidden items-center gap-8 md:flex">
            {nav.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="text-sm font-semibold text-muted-foreground transition-colors hover:text-brand"
              >
                {item.label}
              </a>
            ))}
          </nav>
          <a
            href="#contato"
            className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground shadow-brand transition-transform hover:-translate-y-0.5"
          >
            Entre em contato <ArrowRight className="h-4 w-4" />
          </a>
        </div>
      </header>

      <main id="topo">
        <section className="surface-soft relative overflow-hidden">
          <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-20 md:grid-cols-2 md:py-28">
            <div>
              <h1 className="text-4xl font-extrabold leading-[1.08] tracking-tight text-brand-deep sm:text-5xl">
                A transformação <span className="text-gradient-brand">digital</span> que sua empresa sempre sonhou.
              </h1>
              <div className="mt-6 h-1 w-16 rounded-full bg-primary" />
              <p className="mt-6 max-w-md text-base leading-relaxed text-muted-foreground">
                Transformamos. Digitalizamos. Automatizamos seus processos e decisões utilizando engenharia digital,
                inteligência artificial e tecnologia aplicada ao seu negócio.
              </p>
              <a
                href="#contato"
                className="mt-9 inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3.5 text-sm font-semibold text-primary-foreground shadow-brand transition-transform hover:-translate-y-0.5"
              >
                Entre em contato <ArrowRight className="h-4 w-4" />
              </a>
            </div>
            <div className="relative">
              <div className="absolute -inset-6 rounded-[2.5rem] bg-primary/10 blur-2xl" aria-hidden />
              <img
                src={banner.url}
                alt="Letra W da Wevitria em estilo digital com indicadores de performance"
                className="relative w-full rounded-3xl bg-card object-contain p-6 shadow-elevated"
              />
            </div>
          </div>
        </section>

        <section className="border-y border-border/60 bg-background">
          <div className="mx-auto grid max-w-6xl gap-8 px-5 py-10 sm:grid-cols-2 lg:grid-cols-5">
            {metrics.map((m) => (
              <div key={m.title} className="flex items-start gap-3">
                <m.icon className="mt-0.5 h-6 w-6 shrink-0 text-brand" />
                <div>
                  <p className="text-sm font-bold leading-snug text-brand-deep">{m.title}</p>
                  <p className="text-xs font-medium text-muted-foreground">{m.value}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section id="quem-somos" className="surface-soft py-20">
          <div className="mx-auto max-w-6xl px-5">
            <div className="grid gap-12 rounded-3xl bg-card p-8 shadow-elevated md:grid-cols-2 md:p-12">
              <div>
                <p className="text-xs font-bold tracking-[0.22em] text-brand">QUEM SOMOS</p>
                <h2 className="mt-4 text-3xl font-extrabold leading-tight tracking-tight text-brand-deep">
                  Engenharia, pessoas e tecnologia caminhando juntas.
                </h2>
                <p className="mt-6 text-sm font-semibold text-foreground">
                  A Wevitria nasceu da inquietação de quem viveu as dores dos processos de engenharia.
                </p>
                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                  Conhecemos as dificuldades do planejamento, os desafios dos custos, as pressões dos cronogramas e as
                  exigências da produção.
                </p>
                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                  Por isso interpretamos e criamos soluções digitais, ágeis e de impacto que tornam a gestão mais
                  simples, fluida e eficiente.
                </p>
              </div>
              <div className="relative flex items-center justify-center overflow-hidden rounded-2xl bg-primary/5">
                <img
                  src={quemSomos.url}
                  alt="Engenharia digital: dashboards, cronogramas e modelo 3D de obra em tela"
                  className="h-full w-full rounded-2xl object-cover"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </section>

        <section id="diferenciais" className="py-20">
          <div className="mx-auto max-w-6xl px-5 text-center">
            <p className="text-xs font-bold tracking-[0.22em] text-brand">DIFERENCIAIS</p>
            <h2 className="mt-3 text-3xl font-extrabold tracking-tight text-brand-deep">O que nos torna diferentes.</h2>
            <div className="mt-12 grid gap-6 text-left sm:grid-cols-2 lg:grid-cols-4">
              {diferenciais.map((d) => (
                <article
                  key={d.title}
                  className="rounded-2xl border border-border/70 bg-card p-6 transition-all hover:-translate-y-1 hover:shadow-elevated"
                >
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                    <d.icon className="h-5 w-5" />
                  </div>
                  <h3 className="mt-5 text-sm font-bold leading-snug text-brand-deep">{d.title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{d.text}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="solucoes" className="surface-soft py-20">
          <div className="mx-auto max-w-6xl px-5 text-center">
            <p className="text-xs font-bold tracking-[0.22em] text-brand">SOLUÇÕES</p>
            <h2 className="mt-3 text-3xl font-extrabold tracking-tight text-brand-deep">
              Tecnologia e engenharia trabalhando juntas.
            </h2>
            <div className="mt-12 grid gap-5 text-left sm:grid-cols-2 lg:grid-cols-3">
              {solucoes.map((s) => (
                <article key={s.title} className="group rounded-2xl bg-card p-6 shadow-brand">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                    <s.icon className="h-5 w-5" />
                  </div>
                  <h3 className="mt-5 text-sm font-bold leading-snug text-brand-deep">{s.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.text}</p>
                  <ArrowRight className="mt-6 h-4 w-4 text-brand transition-transform group-hover:translate-x-1" />
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="contato" className="pb-20">
          <div className="mx-auto grid max-w-6xl gap-8 px-5 pb-14 lg:grid-cols-[0.9fr_1.1fr]">
            <div className="flex flex-col justify-center rounded-3xl bg-primary p-8 text-primary-foreground shadow-elevated">
              <h2 className="text-2xl font-extrabold">Pronto para transformar sua empresa?</h2>
              <p className="mt-3 text-sm text-primary-foreground/85">
                Vamos conversar sobre como podemos simplificar, digitalizar e impulsionar seus resultados.
              </p>
              <ul className="mt-8 space-y-3 text-sm">
                <li className="flex items-center gap-2">
                  <Phone className="h-4 w-4" /> (21) 92001-2910
                </li>
                <li className="flex items-center gap-2">
                  <Mail className="h-4 w-4" /> contato@wevitria.com.br
                </li>
              </ul>
            </div>
            <ContactForm />
          </div>
        </section>
      </main>

      <footer className="border-t border-border/60 bg-background py-12">
        <div className="mx-auto grid max-w-6xl gap-10 px-5 md:grid-cols-3">
          <div>
            <div className="flex items-center gap-3">
              <img src={logo.url} alt="" className="h-9 w-9 object-contain" />
              <span className="text-lg font-extrabold text-brand-deep">wevitria</span>
            </div>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">
              Soluções digitais de engenharia para reduzir custos, ganhar produtividade, automatizar processos e
              integrar sistemas.
            </p>
          </div>
          <div>
            <p className="text-xs font-bold tracking-[0.22em] text-brand">NAVEGAÇÃO</p>
            <ul className="mt-4 space-y-2">
              {nav.map((item) => (
                <li key={item.href}>
                  <a href={item.href} className="text-sm text-muted-foreground transition-colors hover:text-brand">
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="text-xs font-bold tracking-[0.22em] text-brand">CONTATO</p>
            <ul className="mt-4 space-y-3 text-sm text-muted-foreground">
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-brand" /> (21) 92001-2910
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-brand" /> contato@wevitria.com.br
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-brand" /> São Gonçalo – RJ
              </li>
            </ul>
          </div>
        </div>
        <p className="mx-auto mt-10 max-w-6xl px-5 text-xs text-muted-foreground">
          © 2026 Wevitria Digital Engineering. Todos os direitos reservados.
        </p>
      </footer>
    </div>
  );
}
