import { useState } from "react";
import { Mail, MessageCircle, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";

const WHATSAPP_NUMBER = "5521920012910";
const CONTACT_EMAIL = "contato@wevitria.com.br";

const contactSchema = z.object({
  name: z
    .string()
    .trim()
    .nonempty({ message: "Informe seu nome." })
    .max(100, { message: "O nome deve ter no máximo 100 caracteres." }),
  email: z
    .string()
    .trim()
    .nonempty({ message: "Informe seu e-mail." })
    .email({ message: "E-mail inválido." })
    .max(255, { message: "O e-mail deve ter no máximo 255 caracteres." }),
  phone: z
    .string()
    .trim()
    .nonempty({ message: "Informe seu WhatsApp." })
    .max(20, { message: "Número muito longo." })
    .refine((v) => v.replace(/\D/g, "").length >= 10, { message: "Informe DDD + número." }),
  message: z
    .string()
    .trim()
    .nonempty({ message: "Conte brevemente o seu desafio." })
    .max(1000, { message: "A mensagem deve ter no máximo 1000 caracteres." }),
});

type ContactValues = z.infer<typeof contactSchema>;
type FieldErrors = Partial<Record<keyof ContactValues, string>>;

const emptyValues: ContactValues = { name: "", email: "", phone: "", message: "" };

const fieldClass =
  "w-full rounded-xl border border-border bg-background px-4 py-3 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-primary focus:ring-2 focus:ring-primary/20";

export function ContactForm() {
  const [values, setValues] = useState<ContactValues>(emptyValues);
  const [errors, setErrors] = useState<FieldErrors>({});

  const update = (field: keyof ContactValues, value: string) => {
    setValues((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const parsed = contactSchema.safeParse(values);

    if (!parsed.success) {
      const nextErrors: FieldErrors = {};
      for (const issue of parsed.error.issues) {
        const key = issue.path[0] as keyof ContactValues;
        if (!nextErrors[key]) nextErrors[key] = issue.message;
      }
      setErrors(nextErrors);
      toast.error("Revise os campos destacados.");
      return;
    }

    const data = parsed.data;
    const text = [
      "Nova mensagem pelo site Wevitria",
      `Nome: ${data.name}`,
      `E-mail: ${data.email}`,
      `WhatsApp: ${data.phone}`,
      `Desafio: ${data.message}`,
    ].join("\n");

    window.open(
      `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`,
      "_blank",
      "noopener,noreferrer",
    );
    toast.success("Abrimos o WhatsApp com sua mensagem pronta para envio.");
    setValues(emptyValues);
  };

  const mailtoHref = `mailto:${CONTACT_EMAIL}?subject=${encodeURIComponent(
    "Contato pelo site Wevitria",
  )}`;

  return (
    <form onSubmit={handleSubmit} noValidate className="rounded-3xl bg-card p-8 shadow-elevated">
      <h3 className="text-xl font-extrabold text-brand-deep">Envie sua mensagem</h3>
      <p className="mt-2 text-sm text-muted-foreground">
        Preencha os dados e enviamos direto para nosso WhatsApp.
      </p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="name" className="text-xs font-bold text-brand-deep">
            Nome
          </label>
          <input
            id="name"
            name="name"
            maxLength={100}
            value={values.name}
            onChange={(e) => update("name", e.target.value)}
            placeholder="Seu nome"
            className={`mt-2 ${fieldClass}`}
            aria-invalid={Boolean(errors.name)}
          />
          {errors.name && <p className="mt-1.5 text-xs font-medium text-destructive">{errors.name}</p>}
        </div>

        <div>
          <label htmlFor="email" className="text-xs font-bold text-brand-deep">
            E-mail
          </label>
          <input
            id="email"
            name="email"
            type="email"
            maxLength={255}
            value={values.email}
            onChange={(e) => update("email", e.target.value)}
            placeholder="seu@email.com"
            className={`mt-2 ${fieldClass}`}
            aria-invalid={Boolean(errors.email)}
          />
          {errors.email && <p className="mt-1.5 text-xs font-medium text-destructive">{errors.email}</p>}
        </div>

        <div className="sm:col-span-2">
          <label htmlFor="phone" className="text-xs font-bold text-brand-deep">
            Número do WhatsApp
          </label>
          <input
            id="phone"
            name="phone"
            inputMode="tel"
            maxLength={20}
            value={values.phone}
            onChange={(e) => update("phone", e.target.value)}
            placeholder="(21) 99999-9999"
            className={`mt-2 ${fieldClass}`}
            aria-invalid={Boolean(errors.phone)}
          />
          {errors.phone && <p className="mt-1.5 text-xs font-medium text-destructive">{errors.phone}</p>}
        </div>

        <div className="sm:col-span-2">
          <label htmlFor="message" className="text-xs font-bold text-brand-deep">
            Qual é o seu desafio?
          </label>
          <textarea
            id="message"
            name="message"
            rows={4}
            maxLength={1000}
            value={values.message}
            onChange={(e) => update("message", e.target.value)}
            placeholder="Conte brevemente o que sua empresa precisa resolver."
            className={`mt-2 resize-none ${fieldClass}`}
            aria-invalid={Boolean(errors.message)}
          />
          <div className="mt-1.5 flex items-center justify-between gap-3">
            {errors.message ? (
              <p className="text-xs font-medium text-destructive">{errors.message}</p>
            ) : (
              <span />
            )}
            <span className="text-xs text-muted-foreground">{values.message.length}/1000</span>
          </div>
        </div>
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-3">
        <button
          type="submit"
          className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3.5 text-sm font-semibold text-primary-foreground shadow-brand transition-transform hover:-translate-y-0.5"
        >
          <MessageCircle className="h-4 w-4" /> Enviar via WhatsApp
        </button>
        <a
          href={mailtoHref}
          className="inline-flex items-center gap-2 rounded-full border border-border px-6 py-3.5 text-sm font-semibold text-brand-deep transition-colors hover:border-primary hover:text-brand"
        >
          <Mail className="h-4 w-4" /> Prefiro por e-mail
        </a>
      </div>

      <p className="mt-4 flex items-center gap-2 text-xs text-muted-foreground">
        <ShieldCheck className="h-3.5 w-3.5 text-brand" /> Seus dados são usados apenas para o primeiro contato.
      </p>
    </form>
  );
}
